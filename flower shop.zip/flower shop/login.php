<?php
	session_start();
	include("ClassCart.php");
	$flag=true;
	
	// get email account and input password from post
	$Email=$_POST["Email"];
	
	$CreatePassword=$_POST["CreatePassword"];
	// my salt
	$salt='xun';
	$salt_password=$salt.$CreatePassword;
	$hash_password=md5($salt_password);
	
	include('conn.php');
	// search database by email
	$CheckUserName="select * FROM Account WHERE Email='".$Email."'";
	$stmt=oci_parse($connect,$CheckUserName);
	if(!$stmt) 
	{
		echo "An error occurred in parsing the sql string.\n";
		exit;
	}
	
	oci_execute($stmt);
	
	while(oci_fetch($stmt))
	{ // get username and password
		$ConfirmPassword=oci_result($stmt,10);	
		$FirstName=oci_result($stmt,1);
		//echo $ConfirmPassword;
	}
	
	if($hash_password != $ConfirmPassword)
	{ // if password is wrong, then logged failed
		$flag=false;		
	}
	else
	{		
		//set username and email account session
		$flag=true;	
		$_SESSION['Email'] = $Email;
		$_SESSION['UserName'] = $FirstName;			
	}
	// return flag for check
	echo $flag;
	oci_close($connect);
?>