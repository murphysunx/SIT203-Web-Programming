<?php
	include("conn.php");
	// get variables
	$Name=$_POST["Name"];
	$Email=$_POST["Email"];
	$Phone=$_POST["Phone"];
	$Company=$_POST["Company"];
	// convert special characters in company name
	$htmlCompany=htmlentities($Company);
	$Message=$_POST["Message"];
	// convert special character in message
	$htmlMessage=htmlentities($Message);
	
	// query 
	$query="INSERT INTO Advice(Name,Email,PhoneNumber,Company,Message) values(:name,:email,:phonenumber,:company,:message)";
	
	// parse
	$compiled = oci_parse($connect,$query);
	// bind variables
	oci_bind_by_name($compiled,':name',$Name);
	oci_bind_by_name($compiled,':email',$Email);
	oci_bind_by_name($compiled,':phonenumber',$Phone);
	oci_bind_by_name($compiled,':company',$htmlCompany);
	oci_bind_by_name($compiled,':message',$htmlMessage);
	// execute query
	oci_execute($compiled);
	// close connection
	oci_close($connect);
	echo "Thanks for your suggestion, ".$Name;
?>