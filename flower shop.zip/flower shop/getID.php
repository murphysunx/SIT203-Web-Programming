<?php
	$name=$_POST["NAME"];
	// convert certain characters
	$htmlname=htmlentities($name);
	include("conn.php");
	$query="select * FROM Plants WHERE Name='".$name."'";
	
	$stmt=oci_parse($connect,$query);
	if(!$stmt) 
	{
		echo "An error occurred in parsing the sql string.\n";
		exit;
	}
	oci_execute($stmt);
	// set value for returned data first in case of fetching no result
	$ID=$htmlname;
	while(oci_fetch($stmt))
	{
		$ID=oci_result($stmt,1);	
	}
	echo $ID;
	oci_close($connect);
?>