<?php
	include("ClassCart.php");
	session_start();
	// get data on serve
	$flag=true;
	
	$FirstName=$_POST["FirstName"];
	$LastName=$_POST["LastName"];
	$UnitNumber=$_POST["UnitNumber"];
	$StreetName=$_POST["StreetName"];
	$Suburb=$_POST["Suburb"];
	$State=$_POST["State"];
	$PostalCode=$_POST["PostalCode"];
	$PhoneNumber=$_POST["PhoneNumber"];
	$Email=$_POST["Email"];
	$CreatePassword=$_POST["CreatePassword"];
	$ConfirmPassword=$_POST["ConfirmPassword"];
	
	include('conn.php');
	$check_query="select * FROM Account WHERE Email='".$Email."'";	
	$stmt=oci_parse($connect,$check_query);
	if(!$stmt) 
	{
		echo "An error occurred in parsing the sql string.\n";
		exit;
	}
	oci_execute($stmt);
	
	while(oci_fetch($stmt))
	{
		// if email has been registered
		$flag=false;
		//echo "error: this account has registered before. <a href='javascript: history.back(-1)'>return</a>";	
		//exit;	
	}
	
	if($flag)
	{  // insert user info into database
		// my salt
		$salt='xun';
		$salt_password=$salt.$ConfirmPassword;
		$encrypt_password=md5($salt_password);
	
		$sql = "INSERT INTO Account(FirstName, LastName, UnitNumber, StreetName, Suburb, State, PostalCode, PhoneNumber, Email, ConfirmPassword)"."VALUES(:FirstName, :LastName, $UnitNumber, :StreetName, :Suburb, :State, $PostalCode, $PhoneNumber, :Email, :ConfirmPassword)";
		
		$compiled = oci_parse($connect,$sql);
		
		oci_bind_by_name($compiled, ':FirstName', $FirstName);
		oci_bind_by_name($compiled, ':LastName', $LastName);
		oci_bind_by_name($compiled, ':StreetName', $StreetName);
		oci_bind_by_name($compiled, ':Suburb', $Suburb);
		oci_bind_by_name($compiled, ':State', $State);
		oci_bind_by_name($compiled, ':Email', $Email);
		oci_bind_by_name($compiled, ':ConfirmPassword', $encrypt_password);
		
		oci_execute($compiled);
		$_SESSION["UserName"]=$FirstName;
		$_SESSION["Email"]=$Email;
		// turn to home page
		header("Location: ass1.php");
	}
	
?>

