<?php
	session_start();
	$captch = $_POST["captcha"];
	if($_SESSION['captcha'] == $captch)
	{
		// user input match the code
		echo true;
	}
	else 
	{ 
		// user input not match the code 
		echo false;
	}
?>