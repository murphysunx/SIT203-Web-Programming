<?php
	include("ClassCart.php");
	include("ClassCaptcha.php");
	session_start();
	
	// create random text
	$_SESSION['captcha'] = rand(10,10000);
	
	// create a new captcha
	$captcha = new captcha();
	$captcha->create($_SESSION['captcha']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Flower Shop</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js" type="text/javascript"></script>
<script src="js/validate.js" type="text/javascript"></script>
<script type="text/javascript">
var captcha = false;
</script>
</head>
<body onload="loadPage()">
<div id="wrap">
       <div class="header">
       		<div class="logo">
            <div id="header">
            </div>  
        <div id="menu">

      <ul>                                                                       
            <li class="selected"><a href="ass1.php">home</a></li>
            <li class="selected"><a href="about.php">about us</a></li>
            <li class="selected"><a href="flowers.php">flowers</a></li>
            <li class="selected"><a href="specials.php">specials gifts</a></li>
            <li class="selected"><a href="myaccount.php">my accout</a></li>
            <li class="selected"><a href="register.php">register</a></li>
            <li class="selected"><a href="contact.php">contact</a></li>
            <li class="selected"><a href="order.php">order</a></li>            
      </ul>
      
      
</div>
            </div>            
                 
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
            <div class="title"><span class="title_icon"><img src="images/bullet1.gif" /></span>My account</div>
        	
			<?php
			if(!isset($_SESSION["UserName"]))
			{ // if user has not logged in, then show the log in form
				echo "<div class='feat_prod_box_details'>
						<div class='contact_form'>
						<div class='form_subtitle'>login into your account</div>
						 <form name='register'>          
							<div class='form_row'>
							<label class='contact'><strong>Email:</strong></label>
							<input type='text' class='contact_input' name='Email' id='email' />             
							</div>  
							<div class='form_row'>
							<label class='contact'><strong>Password:</strong></label>
							<input type='password' class='contact_input' name='CreatePassword' maxlength='15' id='password' />                   
							</div> 
							<div class='form_row'>
							<label class='contact'><strong>Captcha:</strong></label>
							<input type='text' class='contact_input' maxlength='15' id='captcha' onblur='Captcha()' />
							<span>
								<img width='15' height='15' id='captchaCheck' />
							</span>
							                   
							</div>   
							<div class='form_row'>
							      &nbsp;&nbsp;&nbsp;&nbsp;<img src='captcha.png' width='80' height='50' /> 
							</div>    
							                
							<div class='form_row'>
								<div class='terms'>
								<input type='checkbox' name='terms' />
								Remember me
								</div>
							</div> 
							<div class='form_row'>
							<input type='button' onclick='checkIdentification()' class='register' value='login' />
							</div>                      
						  </form>                         
						</div>              
					</div>					
						";
			}
			else
			{ // if user has logged in, then show user recent three month purchase record
				$text="<div class='feat_prod_box_details'>
						<div class='contact_form'>
						<div class='form_subtitle'>Your recent purchase record</div>
						";
				include("conn.php");
				// get date infomation 
				$today=getdate();
				$today_day=$today[mday];
				$today_month=$today[mon];
				$today_year=$today[year];
				$username=$_SESSION["UserName"];
				$query="select * from $username";
				$stmt = oci_parse($connect,$query);
				// array to save items which have been on board
				$item_onboard_array=array();
				if(!$stmt) 
				{
					echo "An error occurred in parsing the sql string.\n";
					exit;
				}
				oci_execute($stmt);
				while(oci_fetch($stmt))
				{
					$month=oci_result($stmt,2);
					$year=oci_result($stmt,3);
					$item_id=oci_result($stmt,5);
					
					
					if($month>=$today_month-3 && $today_month-3>0 && $year==$today_year)
					{ // check period constraints
						$flag=true;
						foreach($item_onboard_array as $value)
						{
							if($value==$item_id)
							{
								$flag=false;
								break;
							}
						}
						if($flag)
						{
							array_push($item_onboard_array,$item_id);
							$qry="select * from Plants where ID='".$item_id."'";
							$compile=oci_parse($connect,$qry);
							if(!$compile)
							{
								echo "An error occurred in parsing the sql string.\n";
								exit;
							}
							oci_execute($compile);
							while(oci_fetch($compile))
							{
								$item_name=oci_result($compile,2);
								$item_photo=oci_result($compile,9);
								
								// show the recent purchase record
								$text.="<div class='new_prod_box'><a href='FlowerModel.php?ID=".$item_id."'>".$item_name."</a><div class='new_prod_bg'><a href='FlowerModel.php?ID=".$item_id."'><img width='120' height='110' src='".$item_photo."' class='thumb' border='0' /></a></div></div>";
							}
						}
						
					}
					else if(($today_month-3)<=0 && ($year+1)==$today_year && $month>=(12-$today_month+1))
					{
						$flag=true;
						foreach($item_onboard_array as $value)
						{
							if($value==$item_id)
							{
								$flag=false;
								break;
							}
						}
						if($flag)
						{
							array_push($item_onboard_array,$item_id);
							$qry="select * from Plants where ID='".$item_id."'";
							$compile=oci_parse($connect,$qry);
							if(!$compile)
							{
								echo "An error occurred in parsing the sql string.\n";
								exit;
							}
							oci_execute($compile);
							while(oci_fetch($compile))
							{
								$item_name=oci_result($compile,2);
								$item_photo=oci_result($compile,9);
								
								// show the recent purchase record
								$text.="<div class='new_prod_box'><a href='FlowerModel.php?ID=".$item_id."'>".$item_name."</a><div class='new_prod_bg'><a href='FlowerModel.php?ID=".$item_id."'><img width='120' height='110' src='".$item_photo."' class='thumb' border='0' /></a></div></div>";
							}
						}
						
					}
				}
				oci_close($connect);
				$text.="	</div>              
						</div>				
						";
				echo $text;	
			}
				
		?>
            
              

            

            
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div id="rightContent" class="right_content">  
        		
         
    	</div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
  </div><!--end of center content-->
       
              
       <div class="footer">
       	<div class="left_footer"><img src="images/footer_logo.gif" /><br /> <a href="http://csscreme.com/freecsstemplates/" title="free templates"><img src="images/csscreme.gif" alt="free templates" title="free templates" border="0" /></a></div>
        <div class="right_footer">
        <a href="ass1.php">home</a>
        <a href="about.php">about us</a>
        <a href="flowers.php">flowers</a>
        <a href="#">privacy policy</a>
        <a href="contact.php">contact us</a>
       
        </div>
        
       
       </div>
    
<div class="disclaimer"><p>&copy;Deakin University, School of Information Technology. This web page has been developed as a student assignment for the unit SIT203: Web Programming. Therefore it is not part of the University's authorised web site. DO NOT USE THE INFORMATION CONTAINED ON THIS WEB PAGE IN ANY WAY.</p></div>
</div>

</body>
</html>